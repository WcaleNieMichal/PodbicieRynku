//<body onload="update()">

    
var queue = [
    img1 = document.getElementById('n1'),
    img2 = document.getElementById('n2'),
    img3 = document.getElementById('n3'),
    img4 = document.getElementById('n4'),
    img5 = document.getElementById('n5'),
    img6 = document.getElementById('n6'),
    ];
var queueLeft = [
    img1 = 0,
    img2 = 0,
    img3 = 0,
    img4 = 0,
    img5 = 0,
    img6 = 0,
    ];


function init()
{
    var arrayLenghts = queue.length;
    var leftPops = 100/(arrayLenghts );
    var left = 0;
    var i = 0;
    queue.forEach(item => {
       
        item.setAttribute("style", "left:"+left+"%");
        queueLeft[i] = left; 
        i++;
        left = left + leftPops;
    });
}


if(document.getElementById('button-left').onclick=move)
{
    var choose = 'left';
}
if(document.getElementById('button-right').onclick=move)
{
    var choose = 'right';
}


function move()
{
    var arrayLenghts = queue.length;
    var leftPops = 100/(arrayLenghts);
    var i = 0;
    var max = leftPops * (arrayLenghts-1);
    if(choose == 'left'){
        queue.forEach(item => 
        {
            queueLeft[i] = (queueLeft[i] - leftPops)>-1?(queueLeft[i] - leftPops):leftPops * (arrayLenghts-1);
            item.setAttribute("style", "left:"+queueLeft[i]+"%");
            i++;
        });
}
    if(choose == 'right')
    {
        queue.forEach(item => 
        {
            queueLeft[i] = (queueLeft[i] + leftPops)<=max?(queueLeft[i] + leftPops):0;
            item.setAttribute("style", "left:"+queueLeft[i]+"%");
            i++;
            
        });
    }
   
}

init();